/*
    Name: Jordan Bankston
    Date: September 15, 2024
    Project: Chada Tech Clocks
*/

#include <iostream>
#include <iomanip> // For formatting time output

using namespace std;

// Function to display both 12-hour and 24-hour clocks
void displayClocks(int hour24, int minute, int second) {
    // 12-hour clock conversion
    int hour12 = hour24 % 12;
    string period = (hour24 >= 12) ? "PM" : "AM";

    if (hour12 == 0) hour12 = 12; // Adjust for 12-hour clock display

    // Display both clocks
    cout << "**************************\n";
    cout << "*      12-Hour Clock      *\n";
    cout << "*      " << setw(2) << setfill('0') << hour12 << ":"
        << setw(2) << setfill('0') << minute << ":"
        << setw(2) << setfill('0') << second << " " << period << "     *\n";
    cout << "**************************\n";

    cout << "**************************\n";
    cout << "*      24-Hour Clock      *\n";
    cout << "*      " << setw(2) << setfill('0') << hour24 << ":"
        << setw(2) << setfill('0') << minute << ":"
        << setw(2) << setfill('0') << second << "          *\n";
    cout << "**************************\n";
}

// Function to add hours, minutes, or seconds
void addTime(int& hour24, int& minute, int& second, int hoursToAdd, int minutesToAdd, int secondsToAdd) {
    second += secondsToAdd;
    if (second >= 60) {
        second -= 60;
        minute++;
    }

    minute += minutesToAdd;
    if (minute >= 60) {
        minute -= 60;
        hour24++;
    }

    hour24 += hoursToAdd;
    if (hour24 >= 24) {
        hour24 -= 24;
    }
}

// Main function
int main() {
    int hour24 = 0, minute = 0, second = 0;
    int choice;

    // Initial display of clocks
    displayClocks(hour24, minute, second);

    while (true) {
        cout << "\nMenu:\n";
        cout << "1 - Add One Hour\n";
        cout << "2 - Add One Minute\n";
        cout << "3 - Add One Second\n";
        cout << "4 - Exit Program\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            addTime(hour24, minute, second, 1, 0, 0);
            displayClocks(hour24, minute, second);
            break;
        case 2:
            addTime(hour24, minute, second, 0, 1, 0);
            displayClocks(hour24, minute, second);
            break;
        case 3:
            addTime(hour24, minute, second, 0, 0, 1);
            displayClocks(hour24, minute, second);
            break;
        case 4:
            cout << "Exiting program.\n";
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
